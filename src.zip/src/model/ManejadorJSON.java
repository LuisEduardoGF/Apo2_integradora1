package model;

public class ManejadorJSON {
}
