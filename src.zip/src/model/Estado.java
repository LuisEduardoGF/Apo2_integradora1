package model;

public enum Estado {
    PENDIENTE,
    EN_PROCESO,
    RESUELTO
}
